@component('mail::message')
    Greetings!
    <br /><br />
    A new TOR subject accreditation has been forwarded to your account. You may review the student TOR on ustptrack.com using the provided credentials or simply access the site by clicking the link (https:ustptrack.com).
    <br /><br />
    Thank you so much for your hard work!
    <br /><br />
    {{ $time }}
@endcomponent