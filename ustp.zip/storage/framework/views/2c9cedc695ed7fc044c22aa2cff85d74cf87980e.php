

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    

    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>


    <div class="row">
        <div class="col-md-12" style="margin-bottom: 10px;">
            <div class="card">
                <div class="card-header" style="font-weight: bold;">For Accreditation</div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($data->code_status->status == 'Pending'): ?>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-header"
                                            style="text-transform: uppercase;text-align:center;color:#14144A;font-weight:bold;">
                                            <?php echo e($data->student->first_name); ?> <?php echo e($data->student->middle_name); ?>

                                            <?php echo e($data->student->last_name); ?>

                                        </div>
                                        <div class="card-body">
                                            <h6>Course: <?php echo e($data->student->course); ?></h6>
                                            <h6>Contact Number: <?php echo e($data->student->contact_number); ?></h6>
                                            <h6>Year Level: <?php echo e($data->student->year_level); ?></h6>
                                            <h6>Accreditation: <span
                                                    class="badge badge-warning"><?php echo e($data->code_status->status); ?></span></h6>
                                            <h6>Date Enrolled: <?php echo e(date('F j, Y', strtotime($data->created_at))); ?></h6>
                                        </div>
                                        <div class="card-footer">
                                            <a href="<?php echo e(url('student_data', [
                                                'student_id' => $data->student_id,
                                                'code' => $data->code,
                                            ])); ?>"
                                                class="btn btn-sm btn-block
                            btn-primary"
                                                style="border-radius: 30px;background:#14144A;">View</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="font-weight: bold;">Completed Accreditation</div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($data->code_status->status == 'Completed'): ?>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-header"
                                            style="text-transform: uppercase;text-align:center;color:#14144A;font-weight:bold;">
                                            <?php echo e($data->student->first_name); ?> <?php echo e($data->student->middle_name); ?>

                                            <?php echo e($data->student->last_name); ?>

                                        </div>
                                        <div class="card-body">
                                            <h6>Course: <?php echo e($data->student->course); ?></h6>
                                            <h6>Contact Number: <?php echo e($data->student->contact_number); ?></h6>
                                            <h6>Year Level: <?php echo e($data->student->year_level); ?></h6>
                                            <h6>Accreditation: <span
                                                    class="badge badge-success"><?php echo e($data->code_status->status); ?></span>
                                            </h6>
                                            <h6>Date Enrolled: <?php echo e(date('F j, Y', strtotime($data->created_at))); ?></h6>
                                        </div>
                                        <div class="card-footer">
                                            <a href="<?php echo e(url('student_data', [
                                                'student_id' => $data->student_id,
                                                'code' => $data->code,
                                            ])); ?>"
                                                class="btn btn-sm btn-block
                            btn-primary"
                                                style="border-radius: 30px;background:#14144A;">View</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/enrolled_students.blade.php ENDPATH**/ ?>