<?php $__env->startComponent('mail::message'); ?>
    Greetings!
    <br /><br />
    A new TOR subject accreditation has been forwarded to your account. You may review the student TOR on ustptrack.com using the provided credentials or simply access the site by clicking the link (https:ustptrack.com).
    <br /><br />
    Thank you so much for your hard work!
    <br /><br />
    <?php echo e($time); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/notify_chair.blade.php ENDPATH**/ ?>