
<?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/home.blade.php ENDPATH**/ ?>