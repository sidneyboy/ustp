<?php $__env->startComponent('mail::message'); ?>
    Greetings!
    <br /><br />
    Your subject <?php echo e($accredited_to); ?> has been <?php echo e($status); ?> by the program chairman, Ms./Mr. <?php echo e($chair_name); ?>. Please check your TOR subject accreditation status on ustptrack.com using your tracking code: <?php echo e($code); ?>.
    <br /><br />
    You may also access the site by clicking the link (https:ustptrack.com). Thank you!
    <br /><br />
    <?php echo e($time); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/send_to_student.blade.php ENDPATH**/ ?>