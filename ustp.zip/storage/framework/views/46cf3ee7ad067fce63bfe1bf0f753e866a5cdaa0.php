<h4><?php echo e($student->last_name . ', ' . $student->first_name . ' ' . $student->middle_name); ?></h4>

<form id="enroll_process">
    <?php echo csrf_field(); ?>
    <div class="row">
        <?php for($i = 0; $i < $number_of_subjects; $i++): ?>
            <div class="col-md-6">
                <label>Subject # <?php echo e($i + 1); ?> </label>
                <select name="subject_id[]" class="form-control" required>
                    <option value="" default>Select</option>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id . '-' . $data->department_id); ?>">
                            <?php echo e($data->title . ' - ' . $data->department->department); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <label>Subject Grade</label>
                <input type="text" class="form-control" required name="grades[]" required>
            </div>
        <?php endfor; ?>

        <div class="col-md-12">
            <br />
            <input type="hidden" name="number_of_subjects" value="<?php echo e($number_of_subjects); ?>">
            <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
            <button class="btn btn-sm btn-primary float-right">Submit</button>
        </div>
    </div>
</form>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $("#enroll_process").on('submit', (function(e) {
        e.preventDefault();
        //$('.loading').show();
        $('#hide_if_trigger').hide();
        $.ajax({
            url: "enroll_process",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                console.log(data);
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'Your work has been saved',
                    showConfirmButton: false,
                    timer: 1500
                })

                location.reload();
            },
        });
    }));
</script>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/enroll_proceed.blade.php ENDPATH**/ ?>