
<?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/auth/register.blade.php ENDPATH**/ ?>