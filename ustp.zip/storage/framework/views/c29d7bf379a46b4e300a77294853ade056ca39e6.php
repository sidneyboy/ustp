

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    

    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 style="text-align: center;font-weight:bold;color:#14144A">TRANSCRIPT OF RECORDS</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                Name: <span style="color:#14144A;font-weight:bold;"><?php echo e($student->first_name); ?>

                                    <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?></span>
                                <br />
                                Email: <span style="color:#14144A;font-weight:bold;"><?php echo e($student->email); ?></span><br />
                                Contact Number: <span
                                    style="color:#14144A;font-weight:bold;"><?php echo e($student->contact_number); ?></span>
                            </div>
                            <div class="col-md-6">
                                Course: <span style="color:#14144A;font-weight:bold;"><?php echo e($student->course); ?></span><br />
                                Year Level: <span
                                    style="color:#14144A;font-weight:bold;"><?php echo e($student->year_level); ?></span><br />
                                Date Processed: <span
                                    style="color:#14144A;font-weight:bold;"><?php echo e(date('F j, Y h:i a', strtotime($student->date_processed))); ?></span>
                            </div>

                            <div class="col-md-12">
                                <br /><br />
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Course Code</th>
                                            <th>Title</th>
                                            <th>Unit</th>
                                            <th>Grade</th>
                                            <th>Department</th>
                                            <th>Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $enrolled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data->status == null): ?>
                                                <tr>
                                                    <td class="align-middle"><?php echo e($data->subject->course_code); ?></td>
                                                    <td class="align-middle"><?php echo e($data->subject->title); ?></td>
                                                    <td class="align-middle"><?php echo e($data->subject->units); ?></td>
                                                    <td class="align-middle"><?php echo e($data->grade); ?></td>
                                                    <td class="align-middle"><?php echo e($data->department->department); ?></td>
                                                    <td>
                                                        

                                                        <!-- Button trigger modal -->
                                                        <button type="button"
                                                            style="border-radius: 30px;background:#14144A"
                                                            class="btn btn-primary btn-block" data-toggle="modal"
                                                            data-target="#exampleModalapproved<?php echo e($data->id); ?>">
                                                            Approved
                                                        </button>

                                                        <!-- Modal -->
                                                        <div class="modal fade"
                                                            id="exampleModalapproved<?php echo e($data->id); ?>" tabindex="-1"
                                                            role="dialog" aria-labelledby="exampleModalLabel"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            <?php echo e($data->subject->title); ?></h5>
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <form action="<?php echo e(route('approved')); ?>" method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="modal-body">
                                                                            <div class="form-group">
                                                                                <label for="">Accredited To(Subject
                                                                                    Code
                                                                                    & Descriptive Title)</label>
                                                                                <input type="text" class="form-control"
                                                                                    required name="accredited_to">

                                                                                <input type="hidden" name="code"
                                                                                    value="<?php echo e($data->code); ?>">
                                                                                <input type="hidden" name="id"
                                                                                    value="<?php echo e($data->id); ?>">
                                                                                <input type="hidden" name="student_id"
                                                                                    value="<?php echo e($data->student_id); ?>">

                                                                            
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">Close</button>
                                                                            <button type="submit"
                                                                                class="btn btn-primary">Save
                                                                                changes</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <br />
                                                        <a href="<?php echo e(url('reject', ['code' => $data->code, 'id' => $data->id, 'student_id' => $data->student_id])); ?>"
                                                            class="btn btn-primary btn-block"
                                                            style="border-radius: 30px;background:#CC1332">Reject</a>
                                                    </td>
                                                </tr>
                                            <?php elseif($data->status == 'Approved'): ?>
                                                <tr>
                                                    <td class="align-middle"><?php echo e($data->subject->course_code); ?></td>
                                                    <td class="align-middle"><?php echo e($data->subject->title); ?></td>
                                                    <td class="align-middle"><?php echo e($data->subject->units); ?></td>
                                                    <td class="align-middle"><?php echo e($data->grade); ?></td>
                                                    <td class="align-middle"><?php echo e($data->department->department); ?></td>
                                                    <td>
                                                        <span
                                                            style="border-radius: 30px;background:#14144A;color:white;padding:8px;">Approved</span>
                                                    </td>
                                                </tr>
                                            <?php elseif($data->status == 'Rejected'): ?>
                                                <tr>
                                                    <td class="align-middle"><?php echo e($data->subject->course_code); ?></td>
                                                    <td class="align-middle"><?php echo e($data->subject->title); ?></td>
                                                    <td class="align-middle"><?php echo e($data->subject->units); ?></td>
                                                    <td class="align-middle"><?php echo e($data->grade); ?></td>
                                                    <td class="align-middle"><?php echo e($data->department->department); ?></td>
                                                    <td>
                                                        <span
                                                            style="border-radius: 30px;background:#CC1332;color:white;padding:8px;">Rejected</span>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h3 style="text-align: center;font-weight:bold;color:#14144A">TOR COPY</h3>
                    </div>
                    <div class="card-body">

                        <!-- Button trigger modal -->
                        <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal">
                            <img src="<?php echo e(asset('/storage/' . $tor->tor_image)); ?>" class="img img-thumbnail"
                                style="border:0px;" alt="">
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">

                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <img src="<?php echo e(asset('/storage/' . $tor->tor_image)); ?>" class="img img-thumbnail"
                                            style="border:0px;" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\ustp\resources\views/student_data.blade.php ENDPATH**/ ?>